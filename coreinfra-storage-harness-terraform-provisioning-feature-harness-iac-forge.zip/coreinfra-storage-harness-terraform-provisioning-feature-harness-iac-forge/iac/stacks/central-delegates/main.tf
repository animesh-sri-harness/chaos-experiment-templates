# ===========================
# Central Delegates Stack
# Installs Harness delegates on the central EKS cluster
# ===========================

# Fetch organization data
data "harness_platform_organization" "this" {
  identifier = var.org_id
}

# Resolve environment configurations
locals {
  environments_resolved = {
    for env_key, env in var.environments : env_key => merge(env, {
      env_identifier   = coalesce(try(env.env_identifier, null), "env_${env_key}")
      infra_identifier = coalesce(try(env.infra_identifier, null), "infra_${env_key}")
      infra_namespace  = coalesce(try(env.k8s_namespace, null), "${env_key}-${var.delegate_namespace_prefix}")
      delegate_name    = coalesce(try(env.delegate_name, null), "${env_key}-delegate-terragrunt")
      delegate_tags    = try(length(env.delegate_tags) > 0 ? env.delegate_tags : null, null) != null ? env.delegate_tags : ["${env_key}-delegate-terragrunt"]
    })
  }
}

# Install Harness Delegates per environment
module "harness_delegate" {
  for_each = local.environments_resolved

  source = "../../../modules/harness/delegate"

  account_id         = var.harness_account_id
  org_id             = var.org_id
  delegate_name      = each.value.delegate_name
  namespace          = each.value.infra_namespace
  manager_endpoint   = var.harness_manager_endpoint
  delegate_image     = var.delegate_image
  helm_repository    = var.delegate_helm_repo
  helm_chart_version = var.delegate_helm_chart_version
  replicas           = 1
  upgrader_enabled   = var.delegate_upgrader_enabled

  # Service Account configuration
  service_account_create      = var.delegate_service_account_create
  service_account_name        = each.value.delegate_name
  service_account_annotations = var.delegate_service_account_annotations

  # Custom CA certificate
  custom_ca_secret = var.delegate_custom_ca_secret
  ca_cert_data     = var.ca_cert_data

  # Custom environment variables
  custom_envs = var.delegate_custom_envs

  values = yamlencode({
    delegateTags = join(",", each.value.delegate_tags)
    description  = "Central delegate for ${each.key} environment"
  })
}
