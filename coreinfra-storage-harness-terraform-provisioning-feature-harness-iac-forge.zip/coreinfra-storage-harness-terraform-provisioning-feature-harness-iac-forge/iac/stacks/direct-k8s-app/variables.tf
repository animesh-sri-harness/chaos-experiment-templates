# ===========================
# Harness Configuration
# ===========================

variable "harness_account_id" {
  type        = string
  description = "Harness account ID"
}

variable "org_id" {
  type        = string
  description = "Harness organization identifier"
}

variable "harness_manager_endpoint" {
  type        = string
  description = "Harness manager endpoint"
}

# ===========================
# Application Configuration
# ===========================

variable "app_slug" {
  type        = string
  description = "Application slug/identifier"
}

variable "app_name" {
  type        = string
  description = "Application display name"
}

variable "app_description" {
  type        = string
  description = "Application description"
  default     = ""
}

# ===========================
# Delegate Configuration
# ===========================

variable "delegate_image" {
  type        = string
  description = "Harness delegate image"
}

variable "delegate_helm_repo" {
  type        = string
  description = "Helm repository for delegate chart"
  default     = "https://app.harness.io/storage/harness-download/delegate-helm-chart/"
}

variable "delegate_helm_chart_version" {
  type        = string
  description = "Helm chart version for delegate"
  default     = "1.0.32"
}

variable "delegate_upgrader_enabled" {
  type        = bool
  description = "Enable auto-upgrade for delegates"
  default     = false
}

variable "delegate_service_account_create" {
  type        = bool
  description = "Whether to create service account for delegates"
  default     = true
}

variable "delegate_custom_ca_secret" {
  type        = string
  description = "Custom CA certificate secret name for delegates"
  default     = ""
}

variable "ca_cert_data" {
  type        = map(string)
  description = "CA certificate data (key-value pairs)"
  default     = {}
  sensitive   = true
}

variable "delegate_custom_envs" {
  type        = list(map(string))
  description = "Custom environment variables for delegates"
  default     = []
}

# ===========================
# Environments Configuration
# ===========================

variable "environments" {
  description = "Deployment environments configuration"
  type        = any
}

variable "tags_set" {
  type        = list(string)
  description = "List of tags in key=value format"
}
