output "project_id" {
  description = "Harness project identifier"
  value       = harness_platform_project.this.identifier
}

output "delegates" {
  description = "Map of deployed delegate details"
  value = {
    for k, v in module.harness_delegate : k => {
      delegate_name = v.delegate_name
      namespace     = v.namespace
    }
  }
}

output "environments_resolved" {
  description = "Resolved environment configurations for this app"
  value       = local.environments_resolved
}
