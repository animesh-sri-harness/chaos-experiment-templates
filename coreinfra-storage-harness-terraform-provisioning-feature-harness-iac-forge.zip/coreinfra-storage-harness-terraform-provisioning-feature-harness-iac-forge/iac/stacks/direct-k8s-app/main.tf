# ===========================
# Direct Kubernetes App Stack
# Deploys delegate on target cluster and creates Harness application
# ===========================

# Fetch organization data
data "harness_platform_organization" "this" {
  identifier = var.org_id
}

locals {
  # Convert app slug for K8s naming (RFC 1123)
  app_slug_k8s = replace(var.app_slug, "_", "-")

  # Resolve environment configurations for this app
  environments_resolved = {
    for env_key, env in var.environments : env_key => merge(env, {
      env_identifier   = coalesce(try(env.env_identifier, null), "env_${env_key}")
      infra_identifier = coalesce(try(env.infra_identifier, null), "infra_${env_key}")
      infra_namespace  = "${local.app_slug_k8s}-${env_key}-harness-delegate"
      delegate_name    = "${local.app_slug_k8s}-${env_key}-delegate"
      delegate_tags    = ["${local.app_slug_k8s}-${env_key}-delegate"]
    })
  }
}

# ===========================
# Harness Project
# ===========================

resource "harness_platform_project" "this" {
  identifier  = var.app_slug
  name        = var.app_name
  org_id      = data.harness_platform_organization.this.id
  description = var.app_description
  tags        = var.tags_set
}

# ===========================
# App-Specific Delegates (per environment)
# ===========================

module "harness_delegate" {
  for_each = local.environments_resolved

  source = "../../../modules/harness/delegate"

  account_id         = var.harness_account_id
  org_id             = var.org_id
  project_id         = harness_platform_project.this.identifier
  delegate_name      = each.value.delegate_name
  namespace          = each.value.infra_namespace
  manager_endpoint   = var.harness_manager_endpoint
  delegate_image     = var.delegate_image
  helm_repository    = var.delegate_helm_repo
  helm_chart_version = var.delegate_helm_chart_version
  replicas           = 1
  upgrader_enabled   = var.delegate_upgrader_enabled

  # Service Account configuration
  service_account_create = var.delegate_service_account_create
  service_account_name   = each.value.delegate_name

  # Custom CA certificate
  custom_ca_secret = var.delegate_custom_ca_secret
  ca_cert_data     = var.ca_cert_data

  # Custom environment variables
  custom_envs = var.delegate_custom_envs

  values = yamlencode({
    delegateTags = each.value.delegate_name
    description  = "App delegate for ${var.app_name} - ${each.key}"
  })

  depends_on = [harness_platform_project.this]
}

# ===========================
# Harness Application (using app-specific delegates)
# ===========================

module "harness_application" {
  source = "../../../modules/harness/application"

  org_id         = data.harness_platform_organization.this.id
  create_project = false # Project already created above
  app_key        = var.app_slug
  app = {
    name        = var.app_name
    slug        = var.app_slug
    description = var.app_description
  }
  environments = local.environments_resolved
  tags_set     = var.tags_set
  access_type  = "direct_kubernetes"

  depends_on = [module.harness_delegate]
}
