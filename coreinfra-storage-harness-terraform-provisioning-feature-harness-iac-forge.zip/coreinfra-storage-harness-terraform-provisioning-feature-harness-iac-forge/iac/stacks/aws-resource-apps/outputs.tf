output "applications" {
  description = "Map of created Harness applications"
  value = {
    for k, v in module.harness_application : k => {
      project_id = k
    }
  }
}
