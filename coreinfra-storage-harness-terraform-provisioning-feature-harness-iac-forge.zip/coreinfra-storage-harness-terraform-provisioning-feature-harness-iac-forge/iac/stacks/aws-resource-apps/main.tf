# ===========================
# AWS Resource Apps Stack
# Creates Harness applications that use central delegates
# ===========================

# Fetch organization data
data "harness_platform_organization" "this" {
  identifier = var.org_id
}

# Create Harness Applications for AWS Resource access type
module "harness_application" {
  for_each = var.applications

  source = "../../../modules/harness/application"

  org_id                      = data.harness_platform_organization.this.id
  app_key                     = each.key
  app                         = merge(each.value, { slug = try(each.value.slug, each.key) })
  environments                = var.environments_resolved
  tags_set                    = var.tags_set
  access_type                 = "aws_resource"
  service_account_annotations = var.delegate_service_account_annotations
}
