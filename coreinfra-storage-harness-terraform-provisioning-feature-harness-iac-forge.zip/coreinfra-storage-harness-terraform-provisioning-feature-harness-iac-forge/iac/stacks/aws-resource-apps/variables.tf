# ===========================
# Harness Configuration
# ===========================

variable "org_id" {
  type        = string
  description = "Harness organization identifier"
}

# ===========================
# Applications Configuration
# ===========================

variable "applications" {
  description = "AWS Resource applications to create"
  type        = any
}

variable "environments_resolved" {
  description = "Resolved environment configurations from central-delegates"
  type        = any
}

variable "tags_set" {
  type        = list(string)
  description = "List of tags in key=value format"
}

variable "delegate_service_account_annotations" {
  type        = map(string)
  description = "Service account annotations to pass to chaos infrastructure (e.g. IRSA role ARN)"
  default     = {}
}
