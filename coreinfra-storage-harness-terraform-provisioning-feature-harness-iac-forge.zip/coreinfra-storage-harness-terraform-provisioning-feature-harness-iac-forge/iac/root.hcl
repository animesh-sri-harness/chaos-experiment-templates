# ===========================
# Root Terragrunt Configuration
# ===========================

locals {
  # Parse the environment from the path
  path_parts = split("/", path_relative_to_include())

  # Environment is always the second element (environments/<env>/...)
  environment = try(local.path_parts[1], "dev")

  # Load environment-specific config
  config_file = "${get_repo_root()}/iac/config/${local.environment}.yaml"
  config      = yamldecode(file(local.config_file))

  # Extract common values
  harness  = local.config.harness
  aws      = local.config.aws
  delegate = local.config.delegate

  state_bucket = coalesce(
    try(local.aws.state_bucket, null),
    "harness-${local.environment}-terraform"
  )

  remote_state_role_arn = try(local.aws.remote_state_assume_role_arn, "")
}

# ===========================
# Remote State Configuration
# ===========================
remote_state {
  backend = "s3"
  config = merge(
    {
      bucket       = local.state_bucket
      key          = "${path_relative_to_include()}/terraform.tfstate"
      region       = local.aws.region
      encrypt      = true
      use_lockfile = true
    },
    local.remote_state_role_arn != "" ? {
      assume_role = {
        role_arn = local.remote_state_role_arn
      }
    } : {}
  )
  generate = {
    path      = "backend.tf"
    if_exists = "overwrite_terragrunt"
  }
}

# ===========================
# Common Provider Generation
# ===========================
generate "versions" {
  path      = "versions.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<EOF
terraform {
  required_version = ">= 1.11"
  
  required_providers {
    harness = {
      source  = "harness/harness"
      version = "~> 0.42"
    }
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.30"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.13"
    }
  }
}
EOF
}

generate "provider_harness" {
  path      = "provider_harness.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<EOF
provider "harness" {
  endpoint   = "${local.harness.endpoint}"
  account_id = "${local.harness.account_id}"
}
EOF
}