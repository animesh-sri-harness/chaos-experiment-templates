# ===========================
# AWS Resource Apps Stack
# Creates Harness applications using central delegates
# ===========================

include "root" {
  path = find_in_parent_folders("root.hcl")
}

include "env" {
  path   = "${get_terragrunt_dir()}/../env.hcl"
  expose = true
}

locals {
  env = include.env.locals
}

terraform {
  source = "${get_repo_root()}//iac/stacks/aws-resource-apps"
}

# Dependency on central-delegates to get resolved environments
dependency "central_delegates" {
  config_path = "../central-delegates"

  mock_outputs = {
    environments_resolved = {
      dev = {
        delegate_name    = "dev-delegate-terragrunt"
        delegate_tags    = ["dev-delegate-terragrunt"]
        infra_namespace  = "dev-harness-delegate-terragrunt"
        env_identifier   = "env_dev"
        infra_identifier = "infra_dev"
        harness_type     = "PreProduction"
        enable_chaos     = true
      }
    }
  }
  mock_outputs_allowed_terraform_commands = ["init", "validate", "plan"]
}

inputs = {
  # Harness Configuration
  org_id = local.env.harness.org_id

  # AWS Resource Applications only
  applications = local.env.aws_resource_apps

  # Resolved environments from central delegates
  environments_resolved = dependency.central_delegates.outputs.environments_resolved

  # Tags
  tags_set = local.env.tags_set

  # Delegate service account annotations (e.g. IRSA role ARN for chaos infra)
  delegate_service_account_annotations = try(local.env.delegate.service_account_annotations, {})
}
