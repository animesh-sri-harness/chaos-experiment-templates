# ===========================
# Central Delegates Stack
# Deploys Harness delegates on central EKS cluster
# ===========================

include "root" {
  path = find_in_parent_folders("root.hcl")
}

include "env" {
  path   = "${get_terragrunt_dir()}/../env.hcl"
  expose = true
}

locals {
  env      = include.env.locals
  harness  = local.env.harness
  aws      = local.env.aws
  delegate = local.env.delegate
}

terraform {
  source = "${get_repo_root()}//iac/stacks/central-delegates"
}

# ===========================
# Generate AWS and K8s Providers for Central Cluster
# ===========================
generate "provider_aws_k8s" {
  path      = "provider_aws_k8s.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<EOF
provider "aws" {
  region = "${local.aws.region}"
}

data "aws_eks_cluster" "central" {
  name = "${local.aws.central_eks_cluster}"
}

data "aws_eks_cluster_auth" "central" {
  name = "${local.aws.central_eks_cluster}"
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.central.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.central.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.central.token
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.central.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.central.certificate_authority[0].data)
    token                  = data.aws_eks_cluster_auth.central.token
  }
}
EOF
}

inputs = {
  # Harness Configuration
  harness_account_id       = local.harness.account_id
  org_id                   = local.harness.org_id
  harness_manager_endpoint = local.harness.manager_endpoint

  # Delegate Configuration
  delegate_image                       = local.delegate.image
  delegate_helm_repo                   = local.delegate.helm_repo
  delegate_helm_chart_version          = local.delegate.helm_chart_version
  delegate_namespace_prefix            = local.delegate.namespace_prefix
  delegate_upgrader_enabled            = local.delegate.upgrader_enabled
  delegate_service_account_create      = local.delegate.service_account_create
  delegate_service_account_annotations = try(local.delegate.service_account_annotations, {})
  delegate_custom_ca_secret            = local.delegate.custom_ca_secret
  delegate_custom_envs                 = local.delegate.custom_envs

  # CA Certs passed via environment variables
  ca_cert_data = {
    for k, v in {
      "custom-cert1" = get_env("TF_VAR_ca_cert_custom_cert1", "")
      "custom-cert2" = get_env("TF_VAR_ca_cert_custom_cert2", "")
    } : k => base64decode(v) if v != ""
  }

  # Environments
  environments = local.env.environments
}