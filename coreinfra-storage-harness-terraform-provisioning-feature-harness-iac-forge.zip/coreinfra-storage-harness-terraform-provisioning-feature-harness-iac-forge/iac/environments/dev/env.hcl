# ===========================
# Dev Environment Configuration
# ===========================

locals {
  environment = "dev"

  # Load the configuration file
  config_file = "${get_repo_root()}/iac/config/${local.environment}.yaml"
  config      = yamldecode(file(local.config_file))

  # Extract configuration sections for easy access
  harness      = local.config.harness
  aws          = local.config.aws
  delegate     = local.config.delegate
  environments = local.config.environments
  applications = local.config.applications
  default_tags = local.config.default_tags

  # Filter applications by access type
  aws_resource_apps = {
    for k, v in local.applications : k => v
    if try(v.access_type, "aws_resource") == "aws_resource"
  }

  direct_k8s_apps = {
    for k, v in local.applications : k => v
    if try(v.access_type, "aws_resource") == "direct_kubernetes"
  }

  # Common tags as list for Harness
  tags_set = [for k, v in local.default_tags : "${k}=${v}"]
}
