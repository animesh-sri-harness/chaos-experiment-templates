# ===========================
# Direct Kubernetes App: __APP_SLUG__
# Auto-generated - Do not edit manually
# ===========================

include "root" {
  path = find_in_parent_folders("root.hcl")
}

include "env" {
  path   = "${get_terragrunt_dir()}/../../env.hcl"
  expose = true
}

locals {
  env      = include.env.locals
  harness  = local.env.harness
  delegate = local.env.delegate

  # App configuration from dev.yaml
  app_key = "__APP_SLUG__"
  app     = local.env.direct_k8s_apps[local.app_key]
}

terraform {
  source = "${get_repo_root()}//iac/stacks/direct-k8s-app"
}

# ===========================
# Generate App-Specific Providers
# Target cluster: __EKS_CLUSTER_NAME__
# ===========================
generate "provider_aws_k8s" {
  path      = "provider_aws_k8s.tf"
  if_exists = "overwrite_terragrunt"
  contents  = <<PROVIDERS
provider "aws" {
  region = "__AWS_REGION__"
  assume_role {
    role_arn = "__ROLE_ARN__"
  }
}

data "aws_eks_cluster" "target" {
  name = "__EKS_CLUSTER_NAME__"
}

data "aws_eks_cluster_auth" "target" {
  name = "__EKS_CLUSTER_NAME__"
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.target.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.target.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.target.token
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.target.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.target.certificate_authority[0].data)
    token                  = data.aws_eks_cluster_auth.target.token
  }
}
PROVIDERS
}

inputs = {
  # Harness Configuration
  harness_account_id       = local.harness.account_id
  org_id                   = local.harness.org_id
  harness_manager_endpoint = local.harness.manager_endpoint

  # Application Configuration
  app_slug        = local.app_key
  app_name        = local.app.name
  app_description = local.app.description

  # Delegate Configuration
  delegate_image              = local.delegate.image
  delegate_helm_repo          = local.delegate.helm_repo
  delegate_helm_chart_version = local.delegate.helm_chart_version
  delegate_upgrader_enabled   = local.delegate.upgrader_enabled
  delegate_service_account_create = local.delegate.service_account_create
  delegate_custom_ca_secret   = local.delegate.custom_ca_secret
  delegate_custom_envs        = local.delegate.custom_envs

  # CA Certs passed via environment variables
  ca_cert_data = {
    for k, v in {
      "custom-cert1" = get_env("TF_VAR_ca_cert_custom_cert1", "")
      "custom-cert2" = get_env("TF_VAR_ca_cert_custom_cert2", "")
    } : k => base64decode(v) if v != ""
  }

  # Environments
  environments = local.env.environments

  # Tags
  tags_set = local.env.tags_set
}
