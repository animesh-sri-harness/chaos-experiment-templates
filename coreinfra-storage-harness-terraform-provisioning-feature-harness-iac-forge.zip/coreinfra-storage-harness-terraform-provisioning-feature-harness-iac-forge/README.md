# coreinfra-storage-harness-terraform-provisioning
For running automations in Harness Chaos Engineering tool using Terraform

## Repository Overview

This repository manages Harness Chaos Engineering infrastructure using Terragrunt and Terraform. It provisions Harness projects, environments, delegates, and chaos infrastructure across AWS EKS clusters. The architecture supports two access patterns:
- **AWS Resource apps**: Use centralized delegates deployed on a shared control cluster
- **Direct Kubernetes apps**: Deploy dedicated delegates on application-specific target clusters

## Architecture

### Directory Structure

```
iac/
├── root.hcl                    # Root Terragrunt config with remote state and provider generation
├── config/
│   └── dev.yaml               # Environment-specific configuration (Harness endpoints, AWS settings, app definitions)
├── environments/
│   └── dev/
│       ├── env.hcl            # Environment locals that filter apps by access_type
│       ├── central-delegates/  # Creates shared delegates on control cluster
│       ├── aws-resource-apps/  # Creates apps using central delegates
│       └── direct-k8s-apps/    # Per-app directories with dedicated delegates
│           ├── my_app/
│           └── cldendur/
└── stacks/
    ├── central-delegates/      # Terraform module for central delegate deployment
    ├── aws-resource-apps/      # Terraform module for AWS resource apps
    └── direct-k8s-app/         # Terraform module for direct K8s apps with app-specific delegates

modules/harness/
├── delegate/                   # Reusable Helm-based delegate module
└── application/                # Harness project, environment, infrastructure, chaos hub resources
```

### Configuration Flow

1. **Root config** (`iac/root.hcl`): Parses environment from path, loads YAML config, generates S3 backend and provider files
2. **Environment config** (`iac/config/dev.yaml`): Single source of truth for Harness endpoints, AWS settings, delegate config, and application definitions
3. **Environment locals** (`iac/environments/dev/env.hcl`): Filters applications into `aws_resource_apps` and `direct_k8s_apps` based on `access_type`
4. **Stack terragrunt.hcl files**: Include root/env configs, define dependencies, pass inputs to Terraform stacks

### Key Terragrunt Patterns

- **Configuration inheritance**: Stacks use `include "root"` and `include "env"` to inherit shared config
- **Dependencies**: `aws-resource-apps` depends on `central-delegates` to get resolved environment data
- **Dynamic provider generation**: Direct K8s apps generate app-specific AWS/K8s/Helm providers using `generate` blocks
- **Mock outputs**: Used in dependencies for `validate` and `plan` commands when dependencies haven't been applied

## Common Development Tasks

### Working with Terragrunt

```bash
# Initialize all stacks in dev environment
cd iac/environments/dev
terragrunt run --all init

# Plan all stacks
terragrunt run --all plan

# Plan specific stack
cd iac/environments/dev/aws-resource-apps
terragrunt plan

# Apply all stacks (requires approval in CI/CD)
terragrunt run --all apply

# Format all HCL files
terragrunt hcl fmt --check
terragrunt hcl fmt  # to fix formatting issues
```

### Adding New Applications

**For AWS Resource apps** (use central delegates):
1. Add application definition to `iac/config/dev.yaml` under `applications` with `access_type: aws_resource`
2. Commit and push - CI/CD will automatically provision the new app using central delegates

**For Direct Kubernetes apps** (dedicated delegates):
1. Add application definition to `iac/config/dev.yaml` under `applications` with:
   ```yaml
   app_name:
     name: app_name
     description: 'app_name - Access Type: Direct Kubernetes'
     access_type: direct_kubernetes
     target_cluster:
       eks_cluster_name: cluster-name
       aws_region: us-east-1
       role_arn: arn:aws:iam::ACCOUNT:role/deployment-role
   ```
2. Create directory: `mkdir -p iac/environments/dev/direct-k8s-apps/app_name`
3. Create `iac/environments/dev/direct-k8s-apps/app_name/terragrunt.hcl` following the pattern in `my_app/terragrunt.hcl`
4. Key considerations:
   - Set `app_key` local to match the key in `dev.yaml`
   - Generate app-specific providers with correct cluster credentials
   - Pass CA certs via environment variables using `get_env("TF_VAR_ca_cert_custom_cert1", "")`

### CI/CD Pipeline

The dev pipeline (`.github/workflows/dev-pipeline.yaml`) runs on:
- Push/PR to `develop` branch with changes to `iac/**` or `modules/**`
- Manual workflow dispatch

**Pipeline stages**:
1. **Plan**: Runs `terragrunt run --all plan` and posts summary to PR comments
2. **Approve Plan**: Manual approval gate using `merck-gen/dso-gha-manual-approval@v1` (requires approval from `TFPLAN_APPROVAL_REVIEWERS`)
3. **Apply**: Runs `terragrunt run --all apply --auto-approve` after approval

**Required secrets**:
- `HARNESS_PLATFORM_API_KEY`: Harness API authentication
- `TF_VAR_CA_CERT_CUSTOM_CERT1`, `TF_VAR_CA_CERT_CUSTOM_CERT2`: Custom CA certificates for delegate pods

**Retry logic**: Init steps include 3-attempt retry with 30s backoff to handle transient GitHub CDN failures

### Remote State

State is stored in S3 with DynamoDB locking:
- Bucket pattern: `harness-{environment}-terraform`
- Key pattern: `{path_relative_to_include}/terraform.tfstate`
- Region: `us-east-1` (from `config/dev.yaml`)
- Encryption enabled
- Assumes role: `arn:aws:iam::398996574965:role/deployment-role`

## Important Constraints

### Naming Conventions
- **App slugs**: Use underscores (e.g., `my_app`) in YAML and Terraform identifiers
- **Kubernetes resources**: Slugs are converted to hyphens (e.g., `my-app`) via `replace(var.app_slug, "_", "-")`
- **Delegate names**: Pattern is `{app_slug_k8s}-{env}-delegate`
- **Namespaces**: Pattern is `{app_slug_k8s}-{env}-harness-delegate` (direct K8s) or `harness-delegate-terragrunt-{env}` (central)

### Provider Requirements
- Terraform >= 1.11
- harness provider ~> 0.42
- aws provider ~> 6.0
- kubernetes provider ~> 2.30
- helm provider ~> 2.13

### Terragrunt Version
- Version 1.0.7 (specified in CI/CD workflow)
- Terraform 1.12.2

### Environment Variable Handling
Direct K8s apps must handle CA certificates passed via environment:
```hcl
ca_cert_data = {
  for k, v in {
    "custom-cert1" = get_env("TF_VAR_ca_cert_custom_cert1", "")
    "custom-cert2" = get_env("TF_VAR_ca_cert_custom_cert2", "")
  } : k => base64decode(v) if v != ""
}
```

## Module Usage

### harness/delegate module
Deploys Harness delegates via Helm chart with:
- Custom CA certificates (stored as Kubernetes secret)
- Custom environment variables (e.g., `POLL_FOR_TASKS`, `STACK_DRIVER_LOGGING_ENABLED`)
- Service account creation
- Configurable replicas and upgrader settings

### harness/application module
Creates complete Harness application setup:
- Project (conditionally created)
- Environments (one per environment key in config)
- Kubernetes connectors (delegate selectors)
- Infrastructure definitions (KubernetesDirect type)
- Chaos infrastructure resources (when `enable_chaos: true`)
- Chaos hub per project

## Testing Changes

Before committing infrastructure changes:
1. Format HCL files: `terragrunt hclfmt`
2. Validate configuration: `cd iac/environments/dev && terragrunt run --all validate`
3. Review plan output carefully for unintended resource changes
4. For new direct K8s apps, verify provider generation in the `generate` block matches target cluster credentials

## Access Types Comparison

| Aspect | AWS Resource | Direct Kubernetes |
|--------|--------------|-------------------|
| Delegate location | Central control cluster | App-specific target cluster |
| Delegate lifecycle | Shared across apps | Per-app deployment |
| Provider config | Static in root.hcl | Dynamic per app in terragrunt.hcl |
| Use case | Apps needing AWS resource access | Apps requiring direct cluster access |
| Terraform stack | `aws-resource-apps` | `direct-k8s-app` |

