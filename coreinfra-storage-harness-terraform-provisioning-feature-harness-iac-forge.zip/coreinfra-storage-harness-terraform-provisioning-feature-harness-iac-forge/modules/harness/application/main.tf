locals {
  slug_k8s       = replace(var.app.slug, "_", "-")
  chaos_hub_id   = coalesce(try(var.app.chaos_hub_id, null), "${var.app.slug}_chaos_hub")
  chaos_hub_name = coalesce(try(var.app.chaos_hub_name, null), "${var.app.name} Chaos Hub")
}

# ===========================
# Project Creation (conditional)
# ===========================

resource "harness_platform_project" "this" {
  count = var.create_project ? 1 : 0

  identifier  = var.app.slug
  name        = var.app.name
  org_id      = var.org_id
  description = coalesce(var.app.description, "Chaos infrastructure for ${var.app.name}")
  tags        = var.tags_set
}

# Chaos Executor Custom role at Org level
resource "harness_platform_roles" "chaos_executor" {
  identifier           = "chaos_executor"
  name                 = "Chaos Executor"
  org_id               = var.org_id
  project_id           = var.app.slug
  description          = "Execute existing chaos experiments and view results. Cannot create or modify."
  allowed_scope_levels = ["project"]

  permissions = [
    "chaos_chaosexperiment_view",
    "chaos_chaosexperiment_execute",
    "chaos_chaosinfrastructure_view",
    "chaos_chaoshub_view",
    "chaos_chaosgameday_view",
    "chaos_chaossecuritygovernance_view",
    "chaos_chaoshub_access"
  ]
}

# ===========================
# User Group Creation
# ===========================

# Project Admin Group
resource "harness_platform_usergroup" "project_admin_group" {
  depends_on = [harness_platform_project.this]

  identifier  = "project_admin_group"
  name        = "Project Admin Group"
  org_id      = var.org_id
  project_id  = var.app.slug
  description = "Full project-level administrative access including chaos"
}

# Chaos Developer Group (Project-scoped alternative)
resource "harness_platform_usergroup" "chaos_developer_group_project" {
  depends_on = [harness_platform_project.this]

  identifier  = "chaos_developer_group"
  name        = "Chaos Developer Group"
  org_id      = var.org_id
  project_id  = var.app.slug
  description = "Can create, edit, and delete chaos experiments, probes, and infrastructure"
}

# Chaos Executor Group (Project-scoped)
resource "harness_platform_usergroup" "chaos_executor_group_project" {
  depends_on = [harness_platform_project.this]

  identifier  = "chaos_executor_group"
  name        = "Chaos Executor Group"
  org_id      = var.org_id
  project_id  = var.app.slug
  description = "Can execute existing chaos experiments and view results. Cannot create or modify."
}

# Project Viewer Group
resource "harness_platform_usergroup" "project_viewer_group" {
  depends_on = [harness_platform_project.this]

  identifier  = "project_viewer_group"
  name        = "Project Viewer Group"
  org_id      = var.org_id
  project_id  = var.app.slug
  description = "Read-only access across all project resources"
}

# ===========================
# Role Bindings Creation
# ===========================

# Project Admin Group → Project Admin Role
resource "harness_platform_role_assignments" "project_admin_binding" {
  org_id                    = var.org_id
  project_id                = var.app.slug
  resource_group_identifier = "_all_project_level_resources"
  role_identifier           = "_project_admin"
  principal {
    identifier = harness_platform_usergroup.project_admin_group.identifier
    type       = "USER_GROUP"
  }
}

# Chaos Developer Group → Chaos Admin Role (built-in)
resource "harness_platform_role_assignments" "chaos_developer_binding" {
  org_id                    = var.org_id
  project_id                = var.app.slug
  resource_group_identifier = "_all_project_level_resources"
  role_identifier           = "_chaos_admin"
  principal {
    identifier = harness_platform_usergroup.chaos_developer_group_project.identifier
    type       = "USER_GROUP"
  }
}

# Chaos Executor Group → Chaos Executor Role (custom, created at project level)
resource "harness_platform_role_assignments" "chaos_executor_binding" {
  org_id                    = var.org_id
  project_id                = var.app.slug
  resource_group_identifier = "_all_project_level_resources"
  role_identifier           = harness_platform_roles.chaos_executor.identifier
  principal {
    identifier = harness_platform_usergroup.chaos_executor_group_project.identifier
    type       = "USER_GROUP"
  }

  depends_on = [harness_platform_roles.chaos_executor]
}

# Project Viewer Group → Project Viewer Role
resource "harness_platform_role_assignments" "project_viewer_binding" {
  org_id                    = var.org_id
  project_id                = var.app.slug
  resource_group_identifier = "_all_project_level_resources"
  role_identifier           = "_project_viewer"
  principal {
    identifier = harness_platform_usergroup.project_viewer_group.identifier
    type       = "USER_GROUP"
  }
}

# ===========================
# Environments
# ===========================

resource "harness_platform_environment" "env" {
  for_each = var.environments

  depends_on = [harness_platform_project.this]

  identifier  = each.value.env_identifier
  name        = upper(each.key)
  org_id      = var.org_id
  project_id  = var.app.slug
  type        = each.value.harness_type
  description = "${var.app.name} – ${each.key}"
  tags        = var.tags_set
}

# Connector
resource "harness_platform_connector_kubernetes" "env" {
  for_each = var.environments

  depends_on = [harness_platform_project.this]

  identifier  = "k8s_${each.key}"
  name        = "K8s-Control-Cluster-${upper(each.key)}"
  org_id      = var.org_id
  project_id  = var.app.slug
  description = "Control EKS – ${each.value.delegate_name}"

  inherit_from_delegate {
    delegate_selectors = each.value.delegate_tags
  }

  tags = var.tags_set
}

# ===========================
# Chaos Infrastructure
# ===========================

# Infrastructure Definition
resource "harness_platform_infrastructure" "env" {
  for_each = var.environments

  depends_on = [
    harness_platform_environment.env,
    harness_platform_connector_kubernetes.env,
  ]

  identifier      = each.value.infra_identifier
  name            = "Infrastructure-${upper(each.key)}"
  org_id          = var.org_id
  project_id      = var.app.slug
  env_id          = harness_platform_environment.env[each.key].id
  type            = "KubernetesDirect"
  deployment_type = "Kubernetes"

  yaml = <<-EOT
    infrastructureDefinition:
      name: Infrastructure-${upper(each.key)}
      identifier: ${each.value.infra_identifier}
      orgIdentifier: ${var.org_id}
      projectIdentifier: ${var.app.slug}
      environmentRef: ${harness_platform_environment.env[each.key].id}
      deploymentType: Kubernetes
      type: KubernetesDirect
      allowSimultaneousDeployments: false
      spec:
        connectorRef: ${harness_platform_connector_kubernetes.env[each.key].identifier}
        namespace: ${each.value.infra_namespace}
        releaseName: ${var.app.slug}-${each.key}-<+INFRA_KEY>
  EOT

  tags = var.tags_set
}

resource "harness_chaos_infrastructure_v2" "env" {
  for_each = { for k, v in var.environments : k => v if v.enable_chaos }

  depends_on = [harness_platform_infrastructure.env]

  org_id         = var.org_id
  project_id     = var.app.slug
  environment_id = harness_platform_environment.env[each.key].id
  infra_id       = harness_platform_infrastructure.env[each.key].id
  name           = var.access_type == "direct_kubernetes" ? "kube-chaos-infra-${each.key}" : "aws-chaos-infra-${each.key}"
  description    = var.access_type == "direct_kubernetes" ? "${var.app.name} chaos infrastructure – ${each.key}, created at the application level delegate for Kubernetes level faults" : "${var.app.name} chaos infrastructure – ${each.key}, created from org level delegate for AWS level faults"

  namespace       = each.value.infra_namespace
  infra_type      = "KUBERNETESV2"
  service_account = coalesce(try(each.value.chaos_service_account, null), each.value.delegate_name)
  annotation      = var.access_type == "aws_resource" ? var.service_account_annotations : null

  tags = var.tags_set
}

# Chaos hub
resource "harness_chaos_hub_v2" "project" {
  depends_on = [harness_platform_project.this]

  org_id      = var.org_id
  project_id  = var.app.slug
  identity    = local.chaos_hub_id
  name        = local.chaos_hub_name
  description = "Chaos hub for ${var.app.name}"
  tags        = [var.app_key, "chaos-hub"]
}