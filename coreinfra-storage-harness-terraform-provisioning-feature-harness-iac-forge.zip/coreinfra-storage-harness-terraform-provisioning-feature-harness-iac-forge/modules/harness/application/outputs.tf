output "project_id" {
  description = "Harness project identifier"
  value       = var.create_project ? harness_platform_project.this[0].id : var.app.slug
}

output "project_name" {
  description = "Harness project name"
  value       = var.create_project ? harness_platform_project.this[0].name : var.app.name
}

output "environments" {
  description = "Map of environment identifiers"
  value = {
    for k, v in harness_platform_environment.env : k => {
      id         = v.id
      identifier = v.identifier
      name       = v.name
      type       = v.type
    }
  }
}

output "chaos_infrastructures" {
  description = "Map of chaos infrastructure details"
  value = {
    for k, v in harness_chaos_infrastructure_v2.env : k => {
      id          = v.id
      name        = v.name
      namespace   = v.namespace
      environment = v.environment_id
    }
  }
}
