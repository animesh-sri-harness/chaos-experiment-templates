variable "org_id" {
  type        = string
  description = "Harness organization ID"
}

variable "create_project" {
  type        = bool
  description = "Whether to create the Harness project (set false if project already exists)"
  default     = true
}

variable "app_key" {
  type        = string
  description = "Application key from the map"
}

variable "app" {
  type        = any
  description = "Application configuration object"
}

variable "environments" {
  type        = any
  description = "Resolved environments configuration"
}

variable "tags_set" {
  type        = list(string)
  description = "List of tags in key=value format"
}

variable "access_type" {
  type        = string
  description = "Access type for the application (aws_resource or direct_kubernetes)"
  default     = "aws_resource"
}

variable "service_account_annotations" {
  type        = map(string)
  description = "Annotations to apply to the chaos infrastructure service account (e.g. IRSA role ARN). Only applied for aws_resource access type."
  default     = {}
}
