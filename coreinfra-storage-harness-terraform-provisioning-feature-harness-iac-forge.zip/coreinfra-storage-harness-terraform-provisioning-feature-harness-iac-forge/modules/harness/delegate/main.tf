# ===========================
# Auto-generate Delegate Token
# ===========================

resource "harness_platform_delegatetoken" "this" {
  name       = "token-${var.delegate_name}"
  account_id = var.account_id
  org_id     = var.org_id
  project_id = var.project_id # null = org-level, set value = project-scoped

  # Optional: Set expiration (null = no expiration)
  # revoke_after = null
}

# ===========================
# Kubernetes Namespace
# ===========================

resource "kubernetes_namespace" "delegate" {
  count = var.create_namespace ? 1 : 0

  metadata {
    name = var.namespace
    labels = {
      "app.kubernetes.io/managed-by" = "terraform"
      "app.kubernetes.io/name"       = "harness-delegate"
    }
  }
}

# ===========================
# Custom CA Certificate Secret
# ===========================

resource "kubernetes_secret" "ca_cert" {
  count = length(var.ca_cert_data) > 0 ? 1 : 0

  metadata {
    name      = var.custom_ca_secret
    namespace = var.namespace
  }

  data = var.ca_cert_data
  type = "Opaque"

  depends_on = [kubernetes_namespace.delegate]
}

# ===========================
# Helm Release - Delegate Installation
# ===========================

resource "helm_release" "delegate" {
  name             = var.delegate_name
  repository       = var.helm_repository
  chart            = "harness-delegate-ng"
  version          = var.helm_chart_version
  namespace        = var.namespace
  create_namespace = false

  timeout = 600
  wait    = false

  values = [data.utils_deep_merge_yaml.values.output]

  depends_on = [kubernetes_namespace.delegate, harness_platform_delegatetoken.this, kubernetes_secret.ca_cert]
}

# ===========================
# Helm Values Configuration
# ===========================

locals {
  # Merge IAM role annotation with any additional annotations
  service_account_annotations = merge(
    var.delegate_iam_role_arn != "" ? { "eks.amazonaws.com/role-arn" = var.delegate_iam_role_arn } : {},
    var.service_account_annotations
  )

  base_values = yamlencode({
    accountId           = var.account_id
    delegateToken       = harness_platform_delegatetoken.this.value # Use auto-generated token
    managerEndpoint     = var.manager_endpoint
    namespace           = var.namespace
    delegateName        = var.delegate_name
    delegateDockerImage = var.delegate_image
    replicas            = var.replicas
    upgrader = {
      enabled = var.upgrader_enabled
    }
    nextGen = var.next_gen

    # Service Account configuration
    serviceAccount = {
      create      = var.service_account_create
      name        = var.service_account_name != "" ? var.service_account_name : null
      annotations = length(local.service_account_annotations) > 0 ? local.service_account_annotations : null
    }

    # Custom CA certificate
    delegateCustomCa = var.custom_ca_secret != "" ? {
      secretName = var.custom_ca_secret
    } : null

    # Custom environment variables
    custom_envs = var.custom_envs
  })
}

data "utils_deep_merge_yaml" "values" {
  input = compact([
    local.base_values,
    var.values,
  ])
}
