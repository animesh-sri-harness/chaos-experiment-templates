terraform {
  required_version = ">= 1.11"

  required_providers {
    harness = {
      source  = "harness/harness"
      version = "~> 0.42"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.30"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.13"
    }
    utils = {
      source  = "cloudposse/utils"
      version = "~> 1.0"
    }
  }
}
