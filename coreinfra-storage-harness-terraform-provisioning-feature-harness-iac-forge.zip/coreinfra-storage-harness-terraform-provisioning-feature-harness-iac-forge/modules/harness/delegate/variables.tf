variable "account_id" {
  type        = string
  description = "Harness account ID"
}

variable "org_id" {
  type        = string
  description = "Harness organization identifier"
}

variable "project_id" {
  type        = string
  description = "Harness project identifier (optional - if set, creates project-scoped token)"
  default     = null
}

variable "delegate_name" {
  type        = string
  description = "Name of the delegate"
}

variable "namespace" {
  type        = string
  description = "Kubernetes namespace for the delegate"
}

variable "create_namespace" {
  type        = bool
  description = "Whether to create the namespace"
  default     = true
}

variable "manager_endpoint" {
  type        = string
  description = "Harness manager endpoint"
  default     = "https://app.harness.io/gratis"
}

variable "delegate_image" {
  type        = string
  description = "Delegate container image"
  default     = "harness/delegate:24.04.82709"
}

variable "helm_repository" {
  type        = string
  description = "Harness Helm chart repository"
  default     = "https://app.harness.io/storage/harness-download/delegate-helm-chart/"
}

variable "helm_chart_version" {
  type        = string
  description = "Harness delegate helm chart version"
  default     = "1.0.32"
}

variable "replicas" {
  type        = number
  description = "Number of delegate replicas"
  default     = 1
}

variable "upgrader_enabled" {
  type        = bool
  description = "Enable auto-upgrade for delegates"
  default     = true
}

variable "next_gen" {
  type        = bool
  description = "Whether this is a NextGen delegate"
  default     = true
}

variable "values" {
  type        = string
  description = "Additional Helm values as YAML string"
  default     = ""
}

variable "service_account_create" {
  type        = bool
  description = "Whether to create service account"
  default     = true
}

variable "service_account_name" {
  type        = string
  description = "Service account name (if not creating)"
  default     = ""
}

variable "delegate_iam_role_arn" {
  type        = string
  description = "Role ARN of the delegate "
  default     = ""
}

variable "custom_ca_secret" {
  type        = string
  description = "Custom CA certificate secret name"
  default     = ""
}

variable "ca_cert_data" {
  type        = map(string)
  description = "CA certificate data (key-value pairs of cert names and base64 data)"
  default     = {}
  sensitive   = true
}

variable "custom_envs" {
  type        = list(map(string))
  description = "Custom environment variables"
  default     = []
}

variable "service_account_annotations" {
  type        = map(string)
  description = "Additional annotations to add to the delegate service account"
  default     = {}
}
