output "delegate_name" {
  description = "Name of the installed delegate"
  value       = helm_release.delegate.name
}

output "namespace" {
  description = "Namespace where delegate is installed"
  value       = var.namespace
}

output "status" {
  description = "Helm release status"
  value       = helm_release.delegate.status
}

output "delegate_token" {
  description = "Auto-generated delegate token"
  value       = harness_platform_delegatetoken.this.value
  sensitive   = true
}

output "token_name" {
  description = "Delegate token name"
  value       = harness_platform_delegatetoken.this.name
}
